package com.capgemini.bank.service;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.exception.DemandDraftException;


public class DemandDraftService implements IDemandDraftService {
	
	
	IDemandDraftDAO demanddraftDao;
	
	public String addDraftDetails(DemandDraft demanddraftbean) throws DemandDraftException{
		
		/*// Input validation Logic         
		try{
			if(!(Pattern.matches("[A-Z a-z]+",demanddraftDao.getCustomer_name()))){
				throw new DemandDraftException("Name contains invalid characters");
			}
			if(!(Pattern.matches("[0-9]{10}+",demanddraftDao.getPhone_number()))){
				throw new DemandDraftException("Mobile Number has invalid characters/invalid length");
			}
			if(demanddraftDao.getDd_amount()<=0){
				throw new DemandDraftException("Invalid amount"); 
			}
		}catch(DemandDraftException e){
			System.err.println(e.getMessage());
			
			System.exit(0);
		}*/
		// End of Input validation Logic       
		
		
		// Commission calculation
		
		int dd_commission = 0;
		try{
			int am = demanddraftbean.getDd_amount();
			dd_commission = 0;
			if(am<=5000){
				dd_commission = 10;
			}else if(am>5000 && am<=10000){
				dd_commission = 41;
			}else if(am>10000 && am<=100000){
				dd_commission = 51;
			}else if(am>100000 && am<=500000){
				dd_commission = 306;
			}else{
				throw new DemandDraftException("DD Amount should be less than Rs.5,00,000");
			}
		}catch(DemandDraftException e){
			System.err.println(e.getMessage());
			
			System.exit(0);
		}
		// End of Commission calculation
		
		demanddraftbean.setDd_commission(dd_commission);
		
		
		// SERVICE LAYER TO DAO LAYER
		DemandDraftDAO dao = new DemandDraftDAO();
		String transaction_id = dao.addDraftDetails(demanddraftbean);
		
		return transaction_id;
		
	}
	public DemandDraft getDemandDraftDetails (int transactionId){
		
		
		return null; 
		
	}
	
		
		
		public boolean validateDemandDraft(DemandDraft demanddraftDao) throws DemandDraftException 
		{
			List<String> validationErrors = new ArrayList<String>();

			
			//Validating contact Number
					if(!(isValidContactNo(demanddraftDao.getPhone_number()))){
						validationErrors.add("\n Contact Number Should be in 10 digit \n");
					}
			//Validating email	
				/*	if(!(isValidDescription(demanddraftDao.getDd_description()))) {
						validationErrors.add("\n   Description Should Be in Alphabets and minimum 3 characters long! \n");
					}*/
					
			//Validating customer name
			if(!(isValidCName(demanddraftDao.getCustomer_name()))) {
				validationErrors.add("\n   CustomerName Should Be In Alphabets and minimum 3 characters long ! \n");
			}
			
			//Validating favor name
					if(!(isValidFavor(demanddraftDao.getIn_favor_of()))) {
						validationErrors.add("\n   In favor of Name Should Be In Alphabets and minimum 3 characters long ! \n");
					}
					
						
			if(!validationErrors.isEmpty())
				throw new DemandDraftException(validationErrors +"");
			return false;
		}
		
		
		
		
	/*public boolean isValidDescription(String description){
			
		Pattern namePattern=Pattern.compile("/\b((?!=|\,|\.).)+(.)\b/g");
		Matcher nameMatcher=namePattern.matcher(description);
		return nameMatcher.matches();
		}*/
		
		
		public boolean isValidCName(String getCName) {
			Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
			Matcher nameMatcher=namePattern.matcher(getCName);
			return nameMatcher.matches();
		}

		public boolean isValidFavor(String getPName) {
			Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
			Matcher nameMatcher=namePattern.matcher(getPName);
			return nameMatcher.matches();
		}

		public boolean isValidContactNo(String No) {
			Pattern contactPattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
			Matcher contactMatcher=contactPattern.matcher(No);
			return contactMatcher.matches();
		}
	public boolean isvalidTranscationId(String transaction_id) {
			
			Pattern idPattern = Pattern.compile("[0-9]{1,4}");
			Matcher idMatcher = idPattern.matcher(transaction_id);
			
			if(idMatcher.matches())
				return true;
			else
				return false;		
		}

		
		
	
	@Override
	public DemandDraft viewDraftDetails(String transaction_id) throws DemandDraftException {
		demanddraftDao=new DemandDraftDAO();
		DemandDraft demanddraftbean=null;
		demanddraftbean=demanddraftDao.viewDraftDetails(transaction_id);
		return demanddraftbean;
	}
	public boolean validateDraftId(String transaction_id) {
		Pattern idPattern = Pattern.compile("[0-9]{1,6}");
		Matcher idMatcher = idPattern.matcher(transaction_id);
		
		if(idMatcher.matches())
			return true;
		else
			return false;		
	}
	}
	
	


